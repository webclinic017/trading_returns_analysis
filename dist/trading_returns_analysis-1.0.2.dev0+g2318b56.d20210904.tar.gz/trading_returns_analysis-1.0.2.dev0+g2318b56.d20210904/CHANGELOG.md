
# Change Log
All notable changes to this project will be documented in this file.
 
## v1.0.1 - 2021-09-09

  Fix bug - Correct versioni of dependencies, trading_exit_price
  

## v1.0.0 - 2021-09-09
 
  Intial release

