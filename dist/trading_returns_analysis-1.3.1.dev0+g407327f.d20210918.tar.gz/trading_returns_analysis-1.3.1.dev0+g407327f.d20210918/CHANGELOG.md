
# Change Log
All notable changes to this project will be documented in this file.
## v1.2.0 - 2021-09-15
  Add feature - add time lag to consider/disregard unrealised return
## v1.2.0 - 2021-09-15
  Add feature to hold or reverse trade based on rolling returns
## v1.2.0 - 2021-09-13

  Fix bug Incorrect cumulative rate
## v1.2.0 - 2021-09-13

  Add feature - Apply kelly criterion position in usd adjustment
## v1.1.1 - 2021-09-09

  Add feature - Addition of cumulative balance given an initial balance and risk per trade
## v1.0.1 - 2021-09-09

  Fix bug - Correct versioni of dependencies, trading_exit_price
  

## v1.0.0 - 2021-09-09
 
  Intial release

